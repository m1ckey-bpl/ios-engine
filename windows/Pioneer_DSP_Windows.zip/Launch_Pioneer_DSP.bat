@echo off
title Pioneer DSP - Sound Tune Audio Engine
cd /d "%~dp0"
echo Starting Pioneer DSP...
python pioneer_app.py
pause
