@echo off
title Pioneer DSP - Sound Tune Audio Engine
cd /d "%~dp0"
echo Starting Pioneer DSP Desktop...
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python pioneer_app.py
) else (
    echo Opening in application mode...
    start msedge --app="file:///%~dp0index.html" 2>nul || start "" "%~dp0index.html"
)

