import http.server
import socketserver
import webbrowser
import os
import sys
import subprocess

PORT = 8520
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

def open_window():
    url = f"http://127.0.0.1:{PORT}"
    edge_paths = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"
    ]
    chrome_paths = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    ]
    
    for p in edge_paths + chrome_paths:
        if os.path.exists(p):
            subprocess.Popen([p, f"--app={url}", "--window-size=430,900", "--window-name=Pioneer DSP"])
            return
            
    webbrowser.open(url)

if __name__ == '__main__':
    os.chdir(DIRECTORY)
    with socketserver.TCPServer(("127.0.0.1", PORT), Handler) as httpd:
        print(f"Pioneer DSP Server running at http://127.0.0.1:{PORT}")
        open_window()
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Stopped.")
